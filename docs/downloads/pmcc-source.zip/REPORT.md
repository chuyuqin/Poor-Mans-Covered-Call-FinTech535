# Poor man’s covered call: AMZN

To: Investment Strategy Team · From: Chuyu Qin · Date: October 9, 2026

Historical period: January 3, 2023–December 31, 2025 · Three calendar years

## Assessment

I tested a poor man’s covered call (PMCC) against a conventional covered call and a 100-share stock position. Each account started with $50,000 and held unused cash. After modeled spreads and commissions, PMCC returned 28.94%, compared with 31.18% for the covered call and 28.99% for stock plus cash.

The PMCC reduced the initial cash required for the long position by 67.0%: $2,810.65 for the call versus $8,515.00 for 100 shares on the same date. It did not improve returns. I would consider it when the objective is to commit less cash to a bullish position, but this study is not enough to recommend live deployment. The next test should cover a sustained decline, another stock, and the broker’s assignment and margin procedures.

## Why AMZN and why these dates

I chose AMZN before comparing strategy returns. It has listed options, pays no cash dividend, and completed its latest split in June 2022, before the sample. This keeps dividend-related exercise incentives and a split out of the main experiment. Historical quote availability was checked in LSEG; a large-cap name alone is not a guarantee of executable option quotes.

The period is three years, not two: 2023, 2024 and 2025. Three complete calendar years provide repeated short-call trades and long-call replacements while avoiding a partial 2026 year. This is a practical scope choice, not a statistically optimal sample length. Starting in 2023 also excludes the preceding decline. AMZN rose strongly during the test, so the results mainly describe the strategy in a favorable period for bullish exposure. Choosing a successful surviving company in 2026 adds selection bias even though I did not choose it by backtest return. Neither choice establishes performance across a full market cycle.

## What the strategy is intended to do

The PMCC buys an in-the-money, long-dated call instead of 100 shares and sells a shorter-dated call against it. The short premium offsets part of the long call’s cost, at the expense of some upside. Unlike stock, the long call expires and is exposed to time decay and changes in implied volatility. It can lose its entire purchase price. A short-call assignment does not automatically exercise the long call.

I use a long delta target of 0.80 to retain substantial stock exposure while reducing the cash outlay. The 0.25 short target leaves room for a price increase before the short strike is reached. Eligible ranges are 0.75–0.85 and 0.20–0.30. These are judgment-based starting rules, not parameters fitted to maximize returns. They also mean the PMCC starts with less directional exposure than 100 shares; it is not an equal-delta comparison.

The long must have 365–540 calendar days remaining. That allows several monthly short-call trades before replacement. The short must have 30–45 days remaining, giving a repeatable monthly cycle. I close the short after the prior session reaches seven days to expiry and replace the long after it reaches 180 days, closing the short first. These buffers limit reliance on near-expiry positions but do not prevent early assignment. Their exact thresholds have not been validated by a parameter sensitivity study.

## Portfolio and contract selection

Each strategy trades one 100-share unit in a $50,000 cash account, without borrowing. The covered call owns 100 shares and uses the same short-call rules; the stock benchmark owns 100 shares with no options. Holding the contract count fixed makes the cash flows comparable and prevents the PMCC’s cash saving from being reinvested as additional leverage. The $50,000 balance is an accounting convention, not a minimum funding requirement. Account returns and drawdowns depend on that cash balance. Idle cash earns zero interest, so the study does not measure the benefit of investing the released cash elsewhere.

The candidate universe contains monthly calls at $40–$300 strikes in $5 increments. This bounds the historical download and makes the universe reproducible. It omits weeklies, intermediate strikes and contracts outside the grid. Contracts are ranked by distance from the target delta, then from 450 days for the long or 35 for the short, then strike (lower long, higher short), then RIC. The long strike must be below spot; the short strike must be above spot and the long strike. New-pair debit including fees must be less than strike width × 100.

Entries require positive bid and ask quotes, a spread no greater than both $2 and 20% of midpoint, and at least one trade on the signal day. The absolute and relative caps screen out visibly wide quotes; one trade is only a minimum activity check. These thresholds do not prove liquidity or executable size. If the selected entry fails, the engine waits rather than choosing a different contract using that day’s Greeks. With no eligible pair it holds cash; with no eligible short it retains the long call or stock alone.

## Data and execution

LSEG supplied 362,300 option-day observations for 2023–2025, plus December 2022 warmup. The cache includes expired contracts and historical bid, ask, delta and volatility fields. It was downloaded in October 2026. Vendor corrections and the exact timing and model conventions of the Greeks were not independently checked.

Signals use the previous stock session. The selected contracts trade at the next session’s ask for purchases and bid for sales, subject to quote and funding checks. These are daily execution proxies. I do not assume midpoint fills. Option commissions are $0.65 per contract per transaction; stock commissions are zero. Both entry quotes must qualify before a pair is booked, and cash must fund the long before the short premium is credited. This assumes paired execution that daily data cannot verify.

The first PMCC entry was 2023-01-04: buy the $70 June 2024 call and sell the $100 February 2023 call, for a net debit of $2,666.30 including fees. The stock accounts began one session earlier. The initial capital comparison uses the PMCC entry date for both instruments.

Daily account value is cash plus stock and long-call value at bid, less short-call liability at ask. Closing trades require an observed price on the execution side. Valuation can carry a missing mark for at most two sessions, explicitly flagged; the baseline needed none. All final positions are liquidated with costs included. The PMCC closed its last long in the scheduled December 2025 roll and remained in cash because no replacement qualified.

## Results and assignment risk

PMCC earned $14,470.00. The short calls collected $9,064.00, but cost $8,382.00 to close. After short-leg commissions, they contributed $635.20; the long calls contributed $13,834.80. The result was driven mainly by bullish long-call exposure. This attribution does not measure the opportunity cost against holding the long calls alone.

Maximum account drawdown was -8.86%, versus -11.40% for stock plus cash. That difference partly reflects different exposure and cash holdings. It should not be read as evidence that the option position itself carries less risk.

Doubling commissions reduced the PMCC return to 28.84%. Charging an additional quarter-spread beyond bid/ask reduced it to 28.35%. If the opposite quote is absent on a closing trade, that stress uses a spread estimate of 20% of the execution-side price, with a $0.01 floor. These scenarios address execution costs, not the robustness of the chosen stock, dates or delta targets.

The baseline assumes no early assignment; scheduled pre-expiry closes produced no expiry assignments. A separate scenario assigns an in-the-money short when its prior-close bid has no more than $0.05 of extrinsic value. It delivers shares at strike, retains the long call, and covers the resulting PMCC short-stock position at the next session’s ask. One assignment occurred and the PMCC returned 28.55%. This tests a specified adverse path, not assignment probability. Borrow availability, overnight financing, broker intervention and margin requirements remain outside the model.

## Review and reproduction

The website includes daily accounts, trade records, skipped decisions, configuration and source code. Seven tests check accounting, prior-session selection, collateral, missing prices and physical assignment. Ending cash reconciles to the trade records. Reproduction uses Python 3.12, pinned dependencies and either the retained raw cache or an entitled LSEG session; raw vendor data remain outside the public source bundle.

Daily observations cannot verify quote age, synchronization, market depth or actual multi-leg fills. Standard 100-share deliverables are assumed; individual adjustment notices were not independently audited. Taxes and interest are excluded. The engine was checked across the full sample, so the annual results are not an untouched holdout. The conclusion is limited to this implementation and sample: less initial cash was required, with no observed return advantage over the conventional covered call.

## References

- [Amazon investor FAQ: dividends and stock splits](https://ir.aboutamazon.com/faqs/default.aspx)
- [Options Industry Council: strategy FAQ](https://www.optionseducation.org/referencelibrary/faq/strategies)
- [Options Industry Council: assignment and exercise risk](https://www.optionseducation.org/videolibrary/assignment-and-exercise-risk)
- [LSEG: Python desktop session](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/quick-start)
- [LSEG: option RIC construction](https://developers.lseg.com/en/article-catalog/article/functions-to-find-option-rics-traded-on-different-exchanges)
